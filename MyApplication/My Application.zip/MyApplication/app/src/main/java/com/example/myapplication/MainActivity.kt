package com.example.myapplication

import android.Manifest
import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.view.*
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.preference.PreferenceManager
import com.google.android.material.textfield.TextInputLayout
import kotlinx.android.synthetic.main.activity_main.*
import org.osmdroid.api.IMapController
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.compass.CompassOverlay
import org.osmdroid.views.overlay.compass.InternalCompassOrientationProvider
import java.io.File
import java.io.FileOutputStream
import java.io.PrintWriter
import java.util.*
import kotlin.collections.ArrayList


private const val REQUEST_PERMISSIONS_REQUEST_CODE = 1


class MainActivity : AppCompatActivity() {

    private lateinit var locationManager: LocationManager
    private lateinit var mapController: IMapController
    private lateinit var tripTitle : String
    private lateinit var ctx: Context
    private lateinit var startTime : String
    private var distanceTraveled : Int = 0
    private var elevationGain : Int = 0
    private var follow : Boolean = false
    private var tripStarted : Boolean = false
    private var hasGps = false
    private var hasNetwork = false
    private var myMarker  : Marker? = null
    private var loc: Location? = null
    private var provider : String? = null

    private var permissions = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.ACCESS_WIFI_STATE,
        Manifest.permission.INTERNET,
        Manifest.permission.ACCESS_NETWORK_STATE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.READ_EXTERNAL_STORAGE
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //request permissions
        requestPermissionsIfNecessary(permissions)


        ctx = applicationContext
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx))
        setContentView(R.layout.activity_main)

        btn_stop_trip.isEnabled = false
        btn_stop_trip.visibility = View.GONE

        //set the map
        mapView.setTileSource(TileSourceFactory.DEFAULT_TILE_SOURCE)
        mapView.setMultiTouchControls(true)

        //set the compass
        val compassOverlay = CompassOverlay(ctx, InternalCompassOrientationProvider(ctx), mapView)
        compassOverlay.enableCompass()
        mapView.overlays.add(compassOverlay)

        //set the home point
        mapController = mapView.controller
        mapController.setZoom(6.5)
        val startPoint = GeoPoint(42.66809381102138, 12.890208341959477)
        mapController.setCenter(startPoint)

        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager


        //set the callback for the buttons
        btn_get_loc.setOnClickListener{
            findMe(locationManager)
        }

        btn_stop_trip.setOnClickListener{
            requestConfirm()
        }

    }

    @SuppressLint("NewApi")
    private fun saveTrip(){
            //method to save the trip made

            val file = File(ctx.filesDir, "History.txt")
            if(!file.exists()){
                file.createNewFile()
            }

            val f = PrintWriter(FileOutputStream(file, true))

            val endTime = Calendar.getInstance().get(Calendar.HOUR_OF_DAY).toString()+":"+Calendar.getInstance().get(
                Calendar.MINUTE
            ).toString()
            val dateN = Calendar.getInstance().get(Calendar.YEAR).toString()+"/"+Calendar.getInstance().get(
                Calendar.MONTH
            ).toString()+"/"+Calendar.getInstance().get(Calendar.DAY_OF_MONTH).toString()

            if (tripTitle != "") {
                    f.println(
                        tripTitle + "_" +
                                dateN
                                + "_" + startTime + "_" +
                                endTime
                                + "_" + distanceTraveled.toString()
                                + "_" + elevationGain.toString()
                    )
                    f.flush()
            } else {
                    f.println(
                        " _" +
                                dateN
                                + "_" + startTime + "_" + endTime
                                + "_" + distanceTraveled.toString() + "_" + elevationGain.toString()
                    )
                    f.flush()
            }
        f.close()
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        //method to stop location tracking
        if (event!= null ) {
            if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                follow = false
            }
        }
        return false
    }

    @SuppressLint("MissingPermission")
    private fun findMe(locM: LocationManager) {
        //method to find the current position
        follow = true

        if (tripStarted && loc!=null){
            setLocation(loc!!)
        }else {

            hasGps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
            hasNetwork = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)


            if (hasGps || hasNetwork) {
                provider = if (hasGps) {
                    LocationManager.GPS_PROVIDER
                } else {
                    LocationManager.NETWORK_PROVIDER
                }

                if (locM.getLastKnownLocation(provider!!) != null && ageMs(
                        locM.getLastKnownLocation(
                            provider!!
                        )!!
                    ) < 30000
                ) {
                    setLocation(locM.getLastKnownLocation(provider!!)!!)
                } else {
                    locM.requestSingleUpdate(provider!!, locationSingleListener, null)
                }


            }
        }

    }

    /*
    fun age_minutes(last: Location): Int {
        return (age_ms(last) / (60 * 1000)).toInt()
    }

     */

    private fun ageMs(last: Location): Long {
        //method to calculate the milliseconds since the last location
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) ageMsApi17(last) else ageMsApiPre17(
            last
        )
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    private fun ageMsApi17(last: Location): Long {
        return (SystemClock.elapsedRealtimeNanos() - last.elapsedRealtimeNanos) / 1000000
    }

    private fun ageMsApiPre17(last: Location): Long {
        return System.currentTimeMillis() - last.time
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun setLocation(loc: Location){
        //method to set the location on the map
        if(myMarker != null){
            mapView.overlays.remove(myMarker)
        }
        myMarker = Marker(mapView)

        if(tripStarted){
            myMarker!!.icon = ctx.resources.getDrawable(R.drawable.walk)
        }else myMarker!!.icon = ctx.resources.getDrawable(R.drawable.map_marker)

        myMarker!!.position = GeoPoint(loc.latitude, loc.longitude)
        myMarker!!.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        mapView.overlays.add(myMarker)

        if(follow) {
            mapController.animateTo(GeoPoint(loc.latitude, loc.longitude))

            if(tripStarted){
                if(mapView.zoomLevelDouble < 18.0){ mapController.setZoom(18.0)}
            }else if (mapView.zoomLevelDouble < 15.0) {
                mapController.setZoom(15.0)
            }

        }
    }

    private val locationSingleListener: LocationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            loc = location
            setLocation(location)
        }
        override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    override fun onResume() {
        super.onResume()
        //this will refresh the osmdroid configuration on resuming.
        mapView.onResume() //needed for compass, my location overlays, v6.0.0 and up
    }

    override fun onPause() {
        super.onPause()
        //this will refresh the osmdroid configuration on resuming.
        mapView.onPause() //needed for compass, my location overlays, v6.0.0 and up
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        //method used for the menu/action bar
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        //method used when clicking on option of the menu/action bar
        when (item.itemId) {
            R.id.MENU_1 -> {
                hasGps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)

                if(!hasGps) {
                    requestGps()
                }else{ requestTitle()}
            }
            R.id.MENU_2 -> {
                val i = Intent(this, HistoryActivity::class.java)
                startActivity(i)
            }
        }
        return false
    }

    private fun requestGps(){
        //method to request the activation of the gps
        val mBuilderGPS = AlertDialog.Builder(this)
        mBuilderGPS.setTitle("Need GPS")
        mBuilderGPS.setMessage("If you want to take a new trip you have to enable Gps")

        mBuilderGPS.setPositiveButton(
            "OK"
        ) { _, _ ->
                val gpsOptionsIntent = Intent(
                    Settings.ACTION_LOCATION_SOURCE_SETTINGS
                    )
                startActivity(gpsOptionsIntent)
        }
        mBuilderGPS.setNegativeButton(
            "Cancel"
        ) { dialog, _ -> dialog.cancel() }

        mBuilderGPS.show()

    }

    private fun requestPermissionsIfNecessary(permissions: Array<String>) {
        //method to check and request permission
        val permissionsToRequest: ArrayList<String> = ArrayList()
        for (permission in permissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                != PackageManager.PERMISSION_GRANTED
            ) {
                // Permission is not granted
                permissionsToRequest.add(permission)
            }
        }
        if (permissionsToRequest.size > 0) {
            ActivityCompat.requestPermissions(
                this,
                permissionsToRequest.toArray(arrayOfNulls(0)),
                REQUEST_PERMISSIONS_REQUEST_CODE
            )
        }
    }

    private fun requestTitle(){
        //method to request title and start the new trip
        val textInputLayout = TextInputLayout(this)
        textInputLayout.setPadding(
            50,
            0,
            50,
            0
        )

        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("New Trip")
        builder.setMessage("Write a title for the new trip if you want")

        tripTitle = ""

        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_TEXT
        textInputLayout.hint = "Name"
        textInputLayout.addView(input)


        builder.setView(textInputLayout)

        // Set up the buttons

        // Set up the buttons
        builder.setPositiveButton(
            "OK"
        ) { _, _ -> tripTitle = input.text.toString()
                    tripStarted = true
                    startTrip()
                    btn_stop_trip.isEnabled = true
                    btn_stop_trip.visibility = View.VISIBLE

        }
        builder.setNegativeButton(
            "Cancel"
        ) { dialog, _ -> dialog.cancel() }

        builder.show()
    }

    private fun requestConfirm(){
        //method to request confirm to end the trip
        val listItems = arrayOf("Save", "Don't save")
        val mBuilder = AlertDialog.Builder(this)
        mBuilder.setTitle("Save Trip?")

        var inputSelection =1

        mBuilder.setSingleChoiceItems(listItems, -1) { _, i ->
            inputSelection = i
        }

        mBuilder.setPositiveButton(
            "OK"
        ) { _, _ ->
            if (inputSelection==0){
                Toast.makeText(ctx, "Saved!", Toast.LENGTH_SHORT).show()
                saveTrip()
            }else { Toast.makeText(ctx, "Don't saved!", Toast.LENGTH_SHORT).show()}

            locationManager.removeUpdates(locationListener)
            btn_stop_trip.isEnabled = false
            btn_stop_trip.visibility = View.GONE
            tripStarted=false
            findMe(locationManager)
        }
        mBuilder.setNegativeButton(
            "Cancel"
        ) { dialog, _ -> dialog.cancel() }

        val mDialog = mBuilder.create()
        mDialog.show()

    }

    @SuppressLint("MissingPermission")
    private fun startTrip(){
        //method to start the trip

        distanceTraveled = 0
        elevationGain = 0

        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager

        hasGps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)

        if(!hasGps){

            val gpsOptionsIntent = Intent(
                Settings.ACTION_LOCATION_SOURCE_SETTINGS
            )
            startActivity(gpsOptionsIntent)
        }else {

            startTime = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                .toString() + ":" + Calendar.getInstance().get(Calendar.MINUTE).toString()
            follow = true
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                10000,
                10F,
                locationListener
            )
        }



    }

    private val locationListener: LocationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            if(loc!=null) {
                distanceTraveled = (distanceTraveled + (loc!!.distanceTo(location))).toInt()
                if(location.altitude> loc!!.altitude){
                    elevationGain = (elevationGain + (location.altitude-loc!!.altitude)).toInt()
                }
            }

            loc = location
            setLocation(location)
        }
        override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

}