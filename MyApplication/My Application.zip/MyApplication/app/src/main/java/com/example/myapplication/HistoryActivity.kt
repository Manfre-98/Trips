package com.example.myapplication



import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_history.*
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.util.*


class HistoryActivity : AppCompatActivity() {
    @Suppress("SENSELESS_COMPARISON")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        actionBar?.setDisplayHomeAsUpEnabled(true)
        setContentView(R.layout.activity_history)
        empty.visibility = View.GONE

        var citta : Array<String> = arrayOf()

        val file = File(this.applicationContext.filesDir, "History.txt")
        if(file.exists()){

            var riga : String?
            val reader = BufferedReader(FileReader(file))
            riga = reader.readLine()

            while (riga != null){
                val toAdd : String
                val st = StringTokenizer(riga, "_")
                val title = st.nextToken()
                val date = st.nextToken()
                val startTime = st.nextToken()
                val endTime = st.nextToken()
                val distanceTraveled = st.nextToken()
                val elevationGain = st.nextToken()

                toAdd = if(title != " "){
                    "Title: $title  Distance traveled: $distanceTraveled  Date: $date \nHour start: $startTime  Hour end: $endTime  Elevation gain: $elevationGain"
                }else{
                    "Trip  Distance traveled: $distanceTraveled  Date: $date " +
                            "\nHour start: $startTime  Hour end: $endTime  Elevation gain: $elevationGain"
                }
                citta = citta.plus(toAdd)

                riga = reader.readLine()
            }
        }

        if(citta.isEmpty()){
            empty.visibility = View.VISIBLE
        }
        else {
            val adapter = ArrayAdapter(this, R.layout.row, citta)
            val listView: ListView = listView
            listView.adapter = adapter
        }

    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

}
